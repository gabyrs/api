<?php

echo "hola";
?>