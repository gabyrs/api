-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 02, 2017 at 03:50 AM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `pagina`
--

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE IF NOT EXISTS `cliente` (
  `idCliente` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ciudad` varchar(50) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`idCliente`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`idCliente`, `nombre`, `email`, `ciudad`, `telefono`, `nickname`, `password`) VALUES
(1, 'Ricardo Rueda Soto', 'rrs1232@gmail.com', 'Ensenada', '1432247', 'rrs1', 'ricardo321'),
(2, 'Victoria Sanchez Ramirez', 'lune_je6742@hotmail.com', 'Ensenada', '2214686', 'vickys5', 'vAwe009'),
(3, 'Mara Ochoa Lopez', 'ochoa_mara2342@hotmail.com', 'Tijuana', '6229024', 'mar0984', 'maraocho244'),
(4, 'Paola Gutierrez Lino', 'pao98483@live.com', 'Ensenada', '1773443', 'ale094_93@hotmail.com', 'alkfne23'),
(5, 'Leticia Fimbres Vazquez', 'leticia_fimbres22@gmail.com\r\n', 'Ensenada', '2256896', 'lety035', 'ksjdbni292');

-- --------------------------------------------------------

--
-- Table structure for table `contacto`
--

CREATE TABLE IF NOT EXISTS `contacto` (
  `idContacto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `telefono` varchar(50) NOT NULL,
  PRIMARY KEY (`idContacto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `contacto`
--

INSERT INTO `contacto` (`idContacto`, `nombre`, `telefono`) VALUES
(1, 'Margarita Lopez Perez', '1765642'),
(2, 'Francisco Garcia', '1225879'),
(3, 'Maria Gonzalez Castro', '1547852'),
(4, 'Cecilia Vazquez', '2569854'),
(5, 'Mirna Castro', '1785249'),
(7, 'Cynthia Jacobo', '2259863'),
(8, 'Maria Jimenez', '2259863'),
(9, 'Mario Jimenez', '2259863'),
(10, 'Mario Jimenez', '2259863');

-- --------------------------------------------------------

--
-- Table structure for table `direccion`
--

CREATE TABLE IF NOT EXISTS `direccion` (
  `idDireccion` int(11) NOT NULL AUTO_INCREMENT,
  `calle` varchar(100) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `codigoPostal` int(10) NOT NULL,
  PRIMARY KEY (`idDireccion`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `direccion`
--

INSERT INTO `direccion` (`idDireccion`, `calle`, `numero`, `codigoPostal`) VALUES
(1, 'Av. Almendras', '2258', 43349),
(2, 'Av. Mexico', '83', 22124);

-- --------------------------------------------------------

--
-- Table structure for table `envio`
--

CREATE TABLE IF NOT EXISTS `envio` (
  `idEnvio` int(11) NOT NULL AUTO_INCREMENT,
  `idOrden` int(11) NOT NULL,
  `idDireccion` int(11) NOT NULL,
  `idContacto` int(11) NOT NULL,
  PRIMARY KEY (`idEnvio`),
  KEY `idOrden` (`idOrden`),
  KEY `idDireccion` (`idDireccion`),
  KEY `idContacto` (`idContacto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `envio`
--

INSERT INTO `envio` (`idEnvio`, `idOrden`, `idDireccion`, `idContacto`) VALUES
(1, 1, 1, 1),
(2, 2, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `orden`
--

CREATE TABLE IF NOT EXISTS `orden` (
  `idOrden` int(11) NOT NULL AUTO_INCREMENT,
  `idCliente` int(11) NOT NULL,
  `idPedido` int(11) NOT NULL,
  `fechaPedido` date NOT NULL,
  `fechaEntrega` date NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY (`idOrden`),
  KEY `idCliente` (`idCliente`),
  KEY `idCliente_2` (`idCliente`),
  KEY `idCliente_3` (`idCliente`),
  KEY `idCliente_4` (`idCliente`),
  KEY `idPedido` (`idPedido`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `orden`
--

INSERT INTO `orden` (`idOrden`, `idCliente`, `idPedido`, `fechaPedido`, `fechaEntrega`, `total`) VALUES
(1, 1, 1, '2017-05-24', '2017-07-05', 50),
(2, 2, 2, '2017-05-24', '2017-07-05', 75),
(3, 3, 3, '2017-06-01', '2017-06-15', 350),
(4, 2, 4, '2017-06-01', '2017-06-05', 70);

-- --------------------------------------------------------

--
-- Table structure for table `pago`
--

CREATE TABLE IF NOT EXISTS `pago` (
  `idPago` int(11) NOT NULL AUTO_INCREMENT,
  `idOrden` int(11) NOT NULL,
  `numTarjeta` int(11) NOT NULL,
  `metodo` varchar(50) NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY (`idPago`),
  KEY `numTarjeta` (`numTarjeta`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `pago`
--

INSERT INTO `pago` (`idPago`, `idOrden`, `numTarjeta`, `metodo`, `total`) VALUES
(1, 1, 242466462, 'Tarjeta', 50),
(2, 2, 347483647, 'Tarjeta', 75);

-- --------------------------------------------------------

--
-- Table structure for table `pedido`
--

CREATE TABLE IF NOT EXISTS `pedido` (
  `idPedido` int(11) NOT NULL AUTO_INCREMENT,
  `idProducto` int(11) NOT NULL,
  `cantidad` int(50) NOT NULL,
  PRIMARY KEY (`idPedido`),
  KEY `idProducto` (`idProducto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `pedido`
--

INSERT INTO `pedido` (`idPedido`, `idProducto`, `cantidad`) VALUES
(1, 1, 10),
(2, 1, 15),
(3, 4, 50),
(4, 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `idProducto` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `sabor` varchar(50) NOT NULL,
  `descripcion` text NOT NULL,
  `precio` float NOT NULL,
  PRIMARY KEY (`idProducto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `producto`
--

INSERT INTO `producto` (`idProducto`, `nombre`, `sabor`, `descripcion`, `precio`) VALUES
(1, 'empanada', 'chocolate', 'empanada de chocolate cubierta de azucar', 5),
(2, 'empanada', 'guayaba', 'Dulce empanada sabor guayaba espolvoreada de azucar', 5),
(3, 'empanada', 'manzana', 'Empanada dulce con pedazos de manzana ', 7),
(4, 'empanada', 'pina', 'Empanada dulce con pedazos de pina', 7),
(5, 'brownie', 'chocolate', 'Brownie de chocolate cubierto de nueces', 10),
(6, 'brownie', 'chocolate blanco', 'Brownie de chocolate blanco cubierto de almendras', 12);

-- --------------------------------------------------------

--
-- Table structure for table `tarjeta`
--

CREATE TABLE IF NOT EXISTS `tarjeta` (
  `numTarjeta` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `compania` varchar(100) NOT NULL,
  `codigo` varchar(50) NOT NULL,
  PRIMARY KEY (`numTarjeta`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tarjeta`
--

INSERT INTO `tarjeta` (`numTarjeta`, `nombre`, `compania`, `codigo`) VALUES
(242466462, 'Mastercard gold', 'BBVA', '9323'),
(347483647, 'Mastercard', 'BANAMEX', '7890'),
(2147483647, 'VISA', 'SANTANDER', '4793');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `envio`
--
ALTER TABLE `envio`
  ADD CONSTRAINT `envio_ibfk_1` FOREIGN KEY (`idOrden`) REFERENCES `orden` (`idOrden`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `envio_ibfk_2` FOREIGN KEY (`idDireccion`) REFERENCES `direccion` (`idDireccion`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `envio_ibfk_3` FOREIGN KEY (`idContacto`) REFERENCES `contacto` (`idContacto`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `orden`
--
ALTER TABLE `orden`
  ADD CONSTRAINT `orden_ibfk_1` FOREIGN KEY (`idCliente`) REFERENCES `cliente` (`idCliente`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orden_ibfk_2` FOREIGN KEY (`idPedido`) REFERENCES `pedido` (`idPedido`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pago`
--
ALTER TABLE `pago`
  ADD CONSTRAINT `pago_ibfk_1` FOREIGN KEY (`numTarjeta`) REFERENCES `tarjeta` (`numTarjeta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pedido`
--
ALTER TABLE `pedido`
  ADD CONSTRAINT `pedido_ibfk_1` FOREIGN KEY (`idProducto`) REFERENCES `producto` (`idProducto`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
